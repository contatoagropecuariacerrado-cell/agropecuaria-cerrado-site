# Agropecuária Cerrado — Pacote de Imagens

Copie todos os arquivos para:

assets/img/

Arquivos:
- logo.svg
- hero.jpg (1920x1080)
- historia.jpg (1600x900)
- recria.jpg (1600x900)
- silagem.jpg (1600x900)
- diario.jpg (1600x900)
- favicon.png (512x512)
- og-image.jpg (1200x630)

Observação:
O arquivo logo.svg é um contêiner SVG com a arte incorporada em PNG.
Ele funciona normalmente no navegador e mantém o nome solicitado,
mas não é uma vetorização por curvas.
